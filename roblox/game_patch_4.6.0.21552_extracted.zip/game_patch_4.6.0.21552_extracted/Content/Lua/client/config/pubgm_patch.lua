-- !!! DO NOT MODIFY THIS FILE. !!!
-- AUTO GENERATE BY pubgm_patch.py 2026-09-08 22:58:48
global_patch_make_time = "" ..
"Patch Version : 4.6.0.21552\n" ..
"Mode : TAPD\n" ..
"Branch : Release4.6.0\n" ..
"Git Engine : 6c090e18646d75682df268d58fc9c448be30910e\n" ..
"Git Survive : 527e70111e550225b284d1f75ec869353be22042\n" ..
"Git Lua : d82f528dc054d1a8bd7e65a240ec44f9c30a0a44\n" ..
"SVN Xls : 1627687\n" ..
"P4 Content : 944507\n" ..
"BuildNo : #1\n" ..
"HostName : PUBGM-VPC180\n" ..
"Mfg. Date : 2026-09-08 22:58:48\n" ..
"Pipeline : #p-cce1d237cb0c4357a8ff1978751a2dd5\n"

global_patch_make_time_map = {
    ["Patch Version"] = "4.6.0.21552",
    ["Mode"] = "TAPD",
    ["Branch"] = "Release4.6.0",
    ["Git Engine"] = "6c090e18646d75682df268d58fc9c448be30910e",
    ["Git Survive"] = "527e70111e550225b284d1f75ec869353be22042",
    ["Git Lua"] = "d82f528dc054d1a8bd7e65a240ec44f9c30a0a44",
    ["SVN Xls"] = "1627687",
    ["P4 Content"] = "944507",
    ["Pipeline"] =  "p-cce1d237cb0c4357a8ff1978751a2dd5",
    ["BuildNo"] =  "#1",
    ["HostName"] = "PUBGM-VPC180",
    ["Mfg. Date"] = "2026-09-08 22:58:48",
}

global_patch_tss = "wdUht0/6P01gkbzDz4F9qg=="
